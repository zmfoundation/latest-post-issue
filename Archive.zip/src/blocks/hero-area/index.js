import './style.editor.scss';
import Edit from './edit';
import { registerBlockType } from '@wordpress/blocks';
import { __ } from '@wordpress/i18n'; 
import { InnerBlocks, RichText } from '@wordpress/editor';

const attributes = {
	heroHeading: {
		type: 'string',
		default: 'We Help You Find and Compare Rates'
	},
	containerBgUrl: {
		type: 'string'
	},
	blockColumn: {
		type: 'number',
		default: 4
	},
	headingSize: {
		type: 'number'
	},
	headingColor: {
		type: 'string'
	},
	hasOverlay: {
		type: 'boolean',
		default: true
	}
};

registerBlockType( 'wt-block/hero-area', {
	title: 'Hero Section', 
	description: 'Hero Section of the Landing Page',
	category: 'landing-page-blocks',
	icon: {
		src: <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0z" fill="none"/><path d="M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z"/></svg>,
	},
	keywords: [
		'Hero Area',
		'Hero Section',
	],
	attributes,
	edit: Edit,
	save: ( { className, attributes } ) => {
		const { heroHeading, containerBgUrl, blockColumn, headingSize, headingColor } = attributes; 
		return(
			<div className="site-hero-area"
				style= {{ 
					backgroundImage: `url(${containerBgUrl})`
				}}
			>
				<div className="gtb-hero-wrapper">
					<div className="hero-heading">
						<RichText.Content
							tagName="h2"
							className={ className }
							value={ heroHeading }
							style={{ color: headingColor, fontSize: headingSize }}
						/>
					</div>
					<div className={ `hero-blocks has-${blockColumn}-cols` }>
						<InnerBlocks.Content />
					</div>
				</div>
			</div>
		)
	}
});