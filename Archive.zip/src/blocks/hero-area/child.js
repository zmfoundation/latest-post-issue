import { __ } from '@wordpress/i18n';
import { registerBlockType } from '@wordpress/blocks';
import { MediaPlaceholder, RichText, PanelColorSettings, InspectorControls, MediaUpload, MediaUploadCheck, BlockControls  } from '@wordpress/editor';
import { isBlobURL } from '@wordpress/blob';
import { Fragment } from 'react';
import { PanelBody, RangeControl, TextControl, Toolbar, IconButton } from '@wordpress/components';

const attributes = {
    url: {
        type: 'string',
    },
    alt: {
        type: 'string'
    },
    id: {
        type: 'number'
    },
    label: {
        type: 'string',
        default: 'MORTGAGE LOANS'
    },
    redirectLink: {
        type: 'string',
        default: '#'
    },
    iconSize: {
        type: 'number',
        default: 80
    },
    labelSize: {
        type: 'number'
    },
    labelOffset: {
        type: 'number'
    },
    blockBg: {
        type: 'string',
        default: '#ffffff'
    },
    labelColor: {
        type: 'string',
        default: '#000000'
    }
}

registerBlockType('wt-block/hero-single-block', {
    title: 'Hero Block',
    description: 'Single Hero Block works as child block for Hero block',
    icon: {
        src: <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M19 4H5c-1.11 0-2 .9-2 2v12c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.89-2-2-2zm0 14H5V8h14v10z"/><path d="M0 0h24v24H0z" fill="none"/></svg>
    },
    category: 'landing-page-blocks',
    supports: {
        reusable: false,
        html: false
    },
    attributes,
    edit: ({ className, attributes, setAttributes }) => {
        const { id, url, alt, label, redirectLink, iconSize, labelSize, labelOffset, blockBg, labelColor } = attributes; 
        return (
            <Fragment>
                <BlockControls>
                    { url &&
                        <Toolbar>
                            { id &&
                                <MediaUploadCheck>
                                    <MediaUpload
                                        onSelect={ ({ id, url, alt })=> setAttributes( { id, url, alt } ) }
                                        allowedTypes={ ['image'] }
                                        value={ id }
                                        render={ ( { open } ) => (
                                            <IconButton
                                                icon="edit"
                                                label="Edit Logo"
                                                onClick={ open }
                                            />
                                        ) }
                                    />
                                </MediaUploadCheck>
                            }
                        </Toolbar>
                    }
                </BlockControls>
                <InspectorControls>        
                    <PanelBody
                        title="Single Block Settings"
                        initialOpen={ false }
                    >
                        <TextControl
                            label= "Redirect Link"
                            onChange={ ( redirectLink ) => setAttributes( { redirectLink } ) }
                            value={ redirectLink }
                        />
                        <RangeControl
                            label="Icon Size"
                            value={ iconSize }
                            onChange={ ( iconSize ) => setAttributes( { iconSize } ) }
                            min={ 1 }
                            max={ 300 }
                        />
                        <RangeControl
                            label="Label Font Size"
                            value={ labelSize }
                            onChange={ ( labelSize ) => setAttributes( { labelSize } ) }
                            min={ 1 }
                            max={ 50 }
                        />
                        <RangeControl
                            label="Label Top Offset"
                            value={ labelOffset }
                            onChange={ ( labelOffset ) => setAttributes( { labelOffset } ) }
                            min={ -30}
                            max={ 50 }
                        />
                    </PanelBody>
                    <PanelColorSettings 
                        title="Color Settings"
                        initialOpen={ false }
                        colorSettings={ [
                            {
                                value: blockBg,
                                onChange: ( blockBg ) => {
                                    setAttributes({ blockBg })
                                },
                                label: 'Single Block Background'
                            },
                            {
                                value: labelColor,
                                onChange: ( labelColor ) => {
                                    setAttributes({ labelColor })
                                },
                                label: 'Label Text Color'
                            }
                        ]}
                    /> 
                </InspectorControls>
                <div className="hero-single-block" style={{ backgroundColor: blockBg }}>
                    <a href={ redirectLink } target="_self" rel="noopener noreferrer">
                        <div className="hero-single-block-icon">
                        { url ?
                                <>
                                    <img src={ url } alt={ alt } style={{ width: iconSize }} />
                                    {
                                        isBlobURL( { url } ) && 
                                        <Spinner/>
                                    }
                                </>
                            : 
                            <MediaPlaceholder
                                onSelect= { ({ id, url, alt })=> setAttributes( { id, url, alt } ) }
                                // onSelectURL={ (url)=> setAttributes( { url, id: null, alt: '' } ) }
                                accept="image/*"
                                allowedTypes={ ['image'] }
                                labels = { { title: 'Upload Icon' } }
                            />
                        }
                        </div>
                        <div className="block-label" style={{ color: labelColor, fontSize: labelSize, marginTop: labelOffset }}>
                            <RichText
                                // tagName="h2"
                                className={ className }
                                value={ label }
                                onChange={ ( label ) => setAttributes( { label } ) }
                                formattingControls={ ['bold','italic'] }
                            />
                        </div>
                    </a>
                </div>
            </Fragment>
        )
    },
    save: ({ attributes, className }) => {
        const { id, url, alt, label, redirectLink, iconSize, labelSize, labelOffset, blockBg, labelColor } = attributes;
        return (
            <div className="hero-single-block" style={{ backgroundColor: blockBg }}>
                <a href={ redirectLink } target="_blank" rel="noopener noreferrer">
                    <div className="hero-single-block-icon">
                        <img src={ url } alt={ alt } style={{ width: iconSize }} />
                    </div>
                    <div className="block-label" style={{ color: labelColor, fontSize: labelSize, marginTop: labelOffset }}>
                        <RichText.Content
                            // tagName="h2"
                            className={ className }
                            value={ label }
                        />
                    </div>
                </a>
            </div>
        )
    }
})