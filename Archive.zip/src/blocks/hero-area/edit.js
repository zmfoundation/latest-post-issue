import './child';
import { __ } from '@wordpress/i18n';
import { Component, Fragment } from '@wordpress/element';
import { MediaPlaceholder, RichText, InnerBlocks, InspectorControls, MediaUpload, MediaUploadCheck, BlockControls } from '@wordpress/editor';
import { isBlobURL } from '@wordpress/blob';
import { PanelBody, ColorPalette, RangeControl, ToggleControl, Toolbar, IconButton } from '@wordpress/components';

const colors = [
	{
		name: "Dark Green",
		color: "#008255"
	},
	{
		name: "White",
		color: "#ffffff"
	},
	{
		name: "Black",
		color: "#000000"
	}
];

class Edit extends Component {
    render() {
		const { className, attributes } = this.props;
		const { heroHeading, containerBgUrl, blockColumn, headingSize, headingColor, hasOverlay } = attributes;
        return (
			<Fragment>
				<InspectorControls>        
					<PanelBody
						title="Container Background Image"
						initialOpen= { false }
					>
						<MediaUpload
							onSelect={ ( newImage ) => this.props.setAttributes({ containerBgUrl: newImage.sizes.full.url }) }
							allowedTypes={ ['image'] }
							value={ containerBgUrl }
							render={ ( { open } ) => (
								<IconButton
									icon="upload"
									onClick={ open }
								>
									Upload Background Image
								</IconButton>
							) }
						/>
					</PanelBody>
					<PanelBody
						title="Block Column Settings"
						initialOpen= { false }
					>
						<RangeControl
							label="Number of Items Per Row"
							value={ blockColumn }
							onChange={ ( blockColumn ) => this.props.setAttributes( { blockColumn } ) }
							min={ 1 }
							max={ 5 }
						/>
					</PanelBody>

					<PanelBody
						title="Heading Style"
						initialOpen= { false }
					>
						<RangeControl
							label="Font Size"
							value={ headingSize }
							onChange={ ( headingSize ) => this.props.setAttributes( { headingSize } ) }
							min={ 1 }
							max={ 100 }
						/>
						<ColorPalette
							colors={ colors }
							onChange={ ( headingColor ) => this.props.setAttributes( { headingColor } ) }
							value={ headingColor }
						/>
					</PanelBody>
				</InspectorControls>
				<BlockControls>
					{ containerBgUrl &&
                        <Toolbar>
							<IconButton
								icon="trash"
								label="Remove Background Image"
								onClick={ ( containerBgUrl )=> this.props.setAttributes( { containerBgUrl: undefined } ) }
							/>
                        </Toolbar>
                    }
				</BlockControls>
				<div className="site-hero-area"
					style= {{ 
						backgroundImage: `url(${containerBgUrl})`
					 }}
				>
					<div className="gtb-hero-wrapper">
						<div className="hero-heading">
							<RichText
								tagName="h2"
								className={ className }
								value={ heroHeading }
								onChange={ ( heroHeading ) => this.props.setAttributes( { heroHeading } ) }
								formattingControls={ ['bold','italic'] }
								style={{ color: headingColor, fontSize: headingSize }}
							/>
						</div>
						<div className={ `hero-blocks has-${blockColumn}-cols` }>
							<InnerBlocks
								allowedBlocks={ ['wt-block/hero-single-block'] }
								template= {[
									["wt-block/hero-single-block"],
									["wt-block/hero-single-block"],
									["wt-block/hero-single-block"],
									["wt-block/hero-single-block"],
									["wt-block/hero-single-block"],
									["wt-block/hero-single-block"],
									["wt-block/hero-single-block"],
									["wt-block/hero-single-block"]
								]}
							/>
						</div>
					</div>
				</div>
			</Fragment>
		)
    }
}

export default Edit;