import './style.editor.scss';
import edit from './edit';
import { registerBlockType } from '@wordpress/blocks';
import { __ } from '@wordpress/i18n'; 
import { InnerBlocks, RichText } from '@wordpress/editor';

registerBlockType( 'wt-block/latest-post', {
	title: 'Latest Posts Section', 
	description: 'Latest Posts Section of the Landing Page',
	category: 'landing-page-blocks',
	icon: 'admin-post',
	keywords: [
		'Latest Post',
		'Post',
	],
	edit: edit,
    save() {
        return null;
    }
});