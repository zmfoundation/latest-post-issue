// import './child';
import { __ } from '@wordpress/i18n';
import { Component, Fragment } from '@wordpress/element';
import { MediaPlaceholder, RichText, PanelColorSettings, InspectorControls, MediaUpload, MediaUploadCheck, BlockControls, InnerBlocks } from '@wordpress/editor';
import { isBlobURL } from '@wordpress/blob';
import { PanelBody, RangeControl, Toolbar, IconButton } from '@wordpress/components';

class LatestPostsEdit extends Component {
    render() {
		return <p> dsjljl </p>;
    }
}

export default LatestPostsEdit;