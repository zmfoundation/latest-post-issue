import { __ } from '@wordpress/i18n';
import { registerBlockType } from '@wordpress/blocks';
import { RichText } from '@wordpress/editor';
const attributes = {
    infoTitle: {
        type: "string",
        default: "FEES"
    },
    infoPrice: {
        type: "string",
        default: "$120"
    },
    infoPlan: {
        type: "string",
        default: "Per Year"
    }
}

registerBlockType('wt-block/info-card-price', {
    title: 'Info Card Price',
    description: 'Price block works as child block for Info Box block',
    icon: {
        src: <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="black" width="18px" height="18px"><path d="M12.75 3h-1.5L6.5 14h2.1l.9-2.2h5l.9 2.2h2.1L12.75 3zm-2.62 7L12 4.98 13.87 10h-3.74zm10.37 8l-3-3v2H5v2h12.5v2l3-3z"/><path d="M0 0h24v24H0z" fill="none"/></svg>
    },
    category: 'custom-blocks',
    supports: {
        reusable: false,
        html: false
    },
    attributes,
    edit: ({ className, attributes, setAttributes }) => {
        const { infoTitle, infoPrice, infoPlan } = attributes; 
        return (
            <div className="wt_single_footer_item">
                <RichText
                    tagName="h5"
                    className={ `wt_info_title ${className}` }
                    value={ infoTitle }
                    onChange={ ( infoTitle ) => setAttributes( { infoTitle } ) }
                    formattingControls= { ['bold','italic'] }
                />
                <RichText
                    tagName="p"
                    className={ `wt_info_price ${className}` }
                    value={ infoPrice }
                    onChange={ ( infoPrice ) => setAttributes( { infoPrice } ) }
                    formattingControls= { ['bold','italic'] }
                />
                <RichText
                    tagName="p"
                    className={ `wt_info_plan ${className}` }
                    value={ infoPlan }
                    onChange={ ( infoPlan ) => setAttributes( { infoPlan } ) }
                    formattingControls= { ['bold','italic'] }
                />
            </div>
        )
    },
    save: ({ attributes, className }) => {
        const { infoTitle, infoPrice, infoPlan } = attributes;
        return (
            <div className="wt_single_footer_item">
                <RichText.Content
                    tagName="h5"
                    className={ `wt_info_title ${className}` }
                    value={ infoTitle }
                />
                <RichText.Content
                    tagName="p"
                    className={ `wt_info_price ${className}` }
                    value={ infoPrice }
                />
                <RichText.Content
                    tagName="p"
                    className={ `wt_info_plan ${className}` }
                    value={ infoPlan }
                />
            </div>
        )
    }
})