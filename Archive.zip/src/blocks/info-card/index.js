import './style.editor.scss';
import Edit from './edit';
import { registerBlockType } from '@wordpress/blocks';
import { __ } from '@wordpress/i18n'; 
import { InnerBlocks, RichText } from '@wordpress/editor';

const attributes = {
	alt: {
        type: 'string',
        source: 'attribute',
        selector: 'img',
        attribute: 'alt',
	},
	url: {
        type: 'string',
        source: 'attribute',
        selector: 'img',
        attribute: 'src',
	},
	id: {
        type: 'number',
	},
	btnText: {
		type: 'string',
		default: 'OPEN ACCOUNT'
	},
	siteInfo: {
		type: 'string',
		default: 'On Blooom Website',
	},
	logoText: {
		type: 'string',
		default: 'BLOOM'
	},
	logoLink: {
		type: 'string',
		default: '#'
	},
	logoSize: {
		type: 'number',
		default: 150
	},
	rating: {
		type: 'string',
		default: 'Rating: 5'
	},
	borderColor: {
		type: 'string',
		default: '#efefef'
	},
	borderWidth: {
		type: 'number'
	},
	titleSize: {
		type: 'number',
		default: 24
	},
	footerCols: {
		type: 'number',
		default: 3
	},
	btnUrl: {
		type: 'string',
		default: '#'
	},
	btnPadding: {
		type: 'number',
		default: 8
	},
	btnRadius: {
		type: 'number',
		default: 0
	},
	btnTextColor: {
		type: 'string',
		default: '#ffffff'
	},
	btnBgColor: {
		type: 'string',
		default: '#008255'
	},
	subTextSize: {
		type: 'number',
		default: 12
	},
	subTextOffset: {
		type: 'number',
		default: 5
	}
};

registerBlockType( 'wt-block/info-card', {
	title: 'Info Card', 
	description: 'Display information',
	category: 'landing-page-blocks',
	icon: {
		src: <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M9 3L7.17 5H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2h-3.17L15 3H9zm3 15c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5z"/><path d="M0 0h24v24H0V0z" fill="none"/><path d="M12 17l1.25-2.75L16 13l-2.75-1.25L12 9l-1.25 2.75L8 13l2.75 1.25z"/></svg>,
	},
	keywords: [
		'Info Box',
		'Info Card', 
		'Information Box'
	],
	attributes,
	edit: Edit,
	save: ( { className, attributes } ) => {
		const { url, alt, btnText, siteInfo, logoText, rating, footerCols, titleSize, borderColor, borderWidth, btnUrl, btnPadding, btnRadius, btnTextColor, btnBgColor, logoLink, logoSize, subTextSize, subTextOffset } = attributes; 
		return(
			<div className="wt_info_box_container" style={ { borderColor: borderColor, borderWidth: borderWidth } }>
				<div className="wt_info_box_action_area">
					<div className="wt_site_logo">
						{ url &&
							<a href={ logoLink } target="_blank" rel="noopener noreferrer">
								<img src={ url } alt={ alt } width={ logoSize } />
							</a>
						}
					</div>
					<a className="wt_action_btn" href={ btnUrl } target="_blank" rel="noopener noreferrer" style={ { borderRadius: btnRadius, paddingTop: btnPadding, paddingBottom: btnPadding, paddingLeft: 2*btnPadding, paddingRight: 2*btnPadding, color: btnTextColor, backgroundColor: btnBgColor } }>
						<RichText.Content
							className={ className }
							value={ btnText }
						/>
					</a>
					<div className="subtext" style={{ fontSize: subTextSize, marginTop: subTextOffset }}>
						<RichText.Content
							className={ className }
							value={ siteInfo }
						/>
					</div>
				</div>
				<div className="wt_info_box_content_area">
					<div className="wt_content_head">
						<div className="wt_logo_title" style={ { fontSize: titleSize } }>
							<RichText.Content
								value={ logoText }
							/>
						</div>
						<div className="wt_header_rating">
							<RichText.Content
								value={ rating }
							/>
						</div>
					</div>
					<div className={ `wt_content_footer has-${footerCols}-cols` }>
						<InnerBlocks.Content />
					</div>
				</div>
			</div>
		)
	}
});