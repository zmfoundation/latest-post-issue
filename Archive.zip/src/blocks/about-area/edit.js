// import './child';
import { __ } from '@wordpress/i18n';
import { Component, Fragment } from '@wordpress/element';
import { MediaPlaceholder, RichText, PanelColorSettings, InspectorControls, MediaUpload, MediaUploadCheck, BlockControls } from '@wordpress/editor';
import { isBlobURL } from '@wordpress/blob';
import { PanelBody, RangeControl, Toolbar, IconButton } from '@wordpress/components';

const colors = [
	{
		name: "Dark Green",
		color: "#008255"
	},
	{
		name: "White",
		color: "#ffffff"
	},
	{
		name: "Black",
		color: "#000000"
	}
];

class Edit extends Component {
    render() {
		const { className, attributes } = this.props;
		const { subHeading, heading, desciption, btnText, btnLink, id, url, alt, subSize, headingSize, btnSize, subColor, headingColor, btnColor } = attributes;
        return (
			<Fragment>
				<InspectorControls>        
					<PanelBody
						title="Font Size Settings"
						initialOpen={ false }
					>
						<RangeControl
							label="Sun Heading Font Size"
							value={ subSize }
							onChange={ ( subSize ) => this.props.setAttributes( { subSize } ) }
							min={ 1 }
							max={ 50 }
						/>
						<RangeControl
							label="Heading Font Size"
							value={ headingSize }
							onChange={ ( headingSize ) => this.props.setAttributes( { headingSize } ) }
							min={ 1 }
							max={ 100 }
						/>
						<RangeControl
							label="Button Font Size"
							value={ btnSize }
							onChange={ ( btnSize ) => this.props.setAttributes( { btnSize } ) }
							min={ 1 }
							max={ 50 }
						/>
					</PanelBody>
					 <PanelColorSettings 
							title="Color Settings"
							initialOpen={ false }
							colorSettings={ [
								{
									label: 'Sub Heading Color',
									value: subColor,
									onChange: (subColor) => {
										this.props.setAttributes({ subColor })
									}
								},
								{
									label: 'Heading Color',
									value: headingColor,
									onChange: (headingColor) => {
										this.props.setAttributes({ headingColor })
									}
								},
								{
									label: 'Button Color',
									value: btnColor,
									onChange: (btnColor) => {
										this.props.setAttributes({ btnColor })
									}
								}
							] }
					/>
				</InspectorControls>
				<BlockControls>
					
				</BlockControls>
				<div className="wt_about_area">
					<div className="wt_content_wrapper">
						<div className="about_area_content">
							<div className="about_area_desc">
								<div className="sub_heading" style={{ fontSize: subSize, color: subColor }}>
									<RichText
										className={ className }
										value={ subHeading }
										onChange={ ( subHeading ) => this.props.setAttributes( { subHeading } ) }
										formattingControls={ ['bold','italic'] }
									/>
								</div>
								<div className="heading">
									<RichText
										tagName="h1"
										className={ className }
										value={ heading }
										onChange={ ( heading ) => this.props.setAttributes( { heading } ) }
										formattingControls={ [  ] }
										style={{ fontSize: headingSize, color: headingColor }}
									/>
								</div>
								<div className="short_description">
									<RichText
										tagName="p"
										className={ className }
										value={ desciption }
										onChange={ ( desciption ) => this.props.setAttributes( { desciption } ) }
									/>
								</div>
								<a className="action_btn" href={ btnLink } target="_self" rel="noopener noreferrer" style={{ fontSize: btnSize, color: btnColor }}>
									<RichText
										className={ className }
										value={ btnText }
									    onChange={ ( btnText ) => this.props.setAttributes( { btnText } ) }
									/>
								</a>
							</div>
							<div className="about_area_photo">
								{ url ?
									<>
										<img src={ url } alt={ alt } />
										{
											isBlobURL( { url } ) && 
											<Spinner/>
										}
									</>
									: 
									<MediaPlaceholder
										onSelect= { ({ id, url, alt })=> this.props.setAttributes( { id, url, alt } ) }
										// onSelectURL={ (url)=> setAttributes( { url, id: null, alt: '' } ) }
										accept="image/*"
										allowedTypes={ ['image'] }
										labels = { { title: 'Upload Image' } }
									/>
								}
							</div>
						</div>
					</div>
				</div>
			</Fragment>
		)
    }
}

export default Edit;