import './style.editor.scss';
import Edit from './edit';
import { registerBlockType } from '@wordpress/blocks';
import { __ } from '@wordpress/i18n'; 
import { InnerBlocks, RichText } from '@wordpress/editor';

const attributes = {
	subHeading: {
		type: 'string',
		default: 'OUR APPROACH'
	},
	heading: {
		type: 'string',
		default: 'Life gets easier when you make more money'
	},
	desciption: {
		type: 'string',
		default: 'Saving is important, but you can only save so much. Whether it’s earning an extra $50 a month or starting a new business on the side, we’ll show you how to do it.'
	},
	btnText: {
		type: 'string',
		default: 'Learn More'
	},
	btnLink: {
		type: 'string',
		default: '#'
	},
	id: {
		type: 'number'
	},
	url: {
		type: 'string'
	},
	alt: {
		type: 'string'
	},
	subSize: {
		type: 'number'
	},
	headingSize: {
		type: 'number'
	},
	btnSize: {
		type: 'number'
	},
	subColor: {
		type: 'string',
		default: '#03c96a'
	},
	headingColor: {
		type: 'string',
		default: '#000000'
	},
	btnColor: {
		type: 'string',
		default: '#000000'
	}
};

registerBlockType( 'wt-block/about-area', {
	title: 'About Section', 
	description: 'About Section of the Landing Page',
	category: 'landing-page-blocks',
	icon: {
		src: <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0z" fill="none"/><path d="M4 6H2v14c0 1.1.9 2 2 2h14v-2H4V6zm16-4H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-1 9H9V9h10v2zm-4 4H9v-2h6v2zm4-8H9V5h10v2z"/></svg>,
	},
	keywords: [
		'About Area',
		'About Section',
	],
	attributes,
	edit: Edit,
	save: ( { className, attributes } ) => {
		const { subHeading, heading, desciption, btnText, btnLink, id, url, alt, subSize, headingSize, btnSize, subColor, headingColor, btnColor } = attributes; 
		return(
			<div className="wt_about_area">
				<div className="wt_content_wrapper">
					<div className="about_area_content">
						<div className="about_area_desc">
							<div className="sub_heading" style={{ fontSize: subSize, color: subColor }}>
								<RichText.Content
									className={ className }
									value={ subHeading }
								/>
							</div>
							<div className="heading">
								<RichText.Content
									tagName="h1"
									className={ className }
									value={ heading }
									style={{ fontSize: headingSize, color: headingColor }}
								/>
							</div>
							<div className="short_description">
								<RichText.Content
									tagName="p"
									className={ className }
									value={ desciption }
								/>
							</div>
							<a className="action_btn" href={ btnLink } target="_blank" rel="noopener noreferrer" style={{ fontSize: btnSize, color: btnColor }}>
								<RichText.Content
									className={ className }
									value={ btnText }
								/>
							</a>
						</div>
						<div className="about_area_photo">
							{ url &&
								<img src={ url } alt={ alt } />
							}
						</div>
					</div>
				</div>
			</div>
		)
	}
});