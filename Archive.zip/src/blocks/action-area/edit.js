// import './child';
import { __ } from '@wordpress/i18n';
import { Component, Fragment } from '@wordpress/element';
import { MediaPlaceholder, RichText, PanelColorSettings, InspectorControls, MediaUpload, MediaUploadCheck, BlockControls, InnerBlocks } from '@wordpress/editor';
import { isBlobURL } from '@wordpress/blob';
import { PanelBody, RangeControl, Toolbar, IconButton } from '@wordpress/components';

const colors = [
	{
		name: "Dark Green",
		color: "#008255"
	},
	{
		name: "White",
		color: "#ffffff"
	},
	{
		name: "Black",
		color: "#000000"
	}
];

class Edit extends Component {
    render() {
		const { className, attributes } = this.props;
		const { actionHeading, headingSize, headingColor, actionBg } = attributes;
        return (
			<Fragment>
				<InspectorControls>
					 <PanelColorSettings 
							title="Container Background"
							initialOpen={ false }
							colorSettings={ [
								{
									label: 'Background Color',
									value: actionBg,
									onChange: ( actionBg ) => this.props.setAttributes( { actionBg } )
								}
							] }
					/>

					<PanelBody
						title="Heading Font Size Settings"
						initialOpen={ false }
					>
						<RangeControl
							value={ headingSize }
							onChange={ ( headingSize ) => this.props.setAttributes( { headingSize } ) }
							min={ 2 }
							max={ 100 }
						/>
					</PanelBody>
					 <PanelColorSettings 
							title="Heading Color Settings"
							initialOpen={ false }
							colorSettings={ [
								{
									label: 'Text Color',
									value: headingColor,
									onChange: ( headingColor ) => this.props.setAttributes( { headingColor } )
								}
							] }
					/>
				</InspectorControls>
				<BlockControls>
					
				</BlockControls>
				<div className="wt_about_area" style={{ backgroundColor: actionBg }}>
					<div className="wt_content_wrapper">
						<div className="action_heading">
							<RichText
								tagName="h2"
								className={ className }
								value={ actionHeading }
								onChange={ ( actionHeading ) => this.props.setAttributes( { actionHeading } ) }
								style={{ fontSize: headingSize, color: headingColor }}
							/>
						</div>
						<div className="action_btn">
							<InnerBlocks
								allowedBlocks={ ['core/button'] }
								template= {[
									["core/button"]
								]}
								templateLock="all"
							/>
						</div>
					</div>
				</div>
			</Fragment>
		)
    }
}

export default Edit;