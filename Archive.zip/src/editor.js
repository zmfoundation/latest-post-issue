// import './blocks/info-card';
import './blocks/hero-area';
import './blocks/about-area';
import './blocks/action-area';
import './blocks/latest-posts';