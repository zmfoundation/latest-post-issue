// import './blocks/info-card/script';
import './blocks/hero-area/script';
import './blocks/about-area/script';
import './blocks/action-area/script';
import './blocks/latest-posts/script';